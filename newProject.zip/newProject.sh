echo "Creating new Project: $1"
cp -r project-template project-template1
mv project-template1 $1
echo "Done!"