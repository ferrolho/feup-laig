#include "GraphScene.h"

GraphScene::GraphScene() {

}

void GraphScene::init() {

}

void GraphScene::update(unsigned long sysTime) {

}

void GraphScene::display() {

}

GraphScene::~GraphScene() {

}
