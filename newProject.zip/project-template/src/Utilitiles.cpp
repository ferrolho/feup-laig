#include "Utilities.h"

const double pi180 = M_PI / 180;

double degToRad(double deg) {
	return deg * pi180;
}
