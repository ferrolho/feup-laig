#pragma once

#define _USE_MATH_DEFINES
#include <cmath>

double degToRad(double deg);
