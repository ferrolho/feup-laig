#pragma once

enum TransformType {
	TRANSLATION, ROTATION, SCALING
};
