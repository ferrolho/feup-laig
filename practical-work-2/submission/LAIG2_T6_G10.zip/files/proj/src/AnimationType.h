#pragma once

enum AnimationType {
	LINEAR, CIRCULAR, NONE
};
