#include "Primitive.h"

Primitive::Primitive() {
}

Primitive::~Primitive() {
}

void Primitive::updateTexture(Texture* texture) {
}
