How to run:
-----------
Open SICStus and type:
> consult('/home/user/git/feup-laig/final-project/submission/prolog-code/server.pl').
> server.