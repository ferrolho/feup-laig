#pragma once

enum AxisID {
	X, Y, Z
};
