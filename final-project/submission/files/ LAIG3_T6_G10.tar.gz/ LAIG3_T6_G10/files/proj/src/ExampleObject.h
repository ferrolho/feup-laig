#pragma once

#include "CGFobject.h"

class ExampleObject: public CGFobject {
public:
	void draw();
};
