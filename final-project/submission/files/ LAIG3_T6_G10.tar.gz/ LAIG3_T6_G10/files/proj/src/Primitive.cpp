#include "Primitive.h"

Primitive::Primitive() {
}

Primitive::~Primitive() {
}

void Primitive::update(unsigned long t) {
}

void Primitive::updateTexture(Texture* texture) {
}
