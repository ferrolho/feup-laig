#include "Transform.h"

Transform::Transform(TransformType type) {
	this->type = type;
}

Transform::~Transform() {
}
